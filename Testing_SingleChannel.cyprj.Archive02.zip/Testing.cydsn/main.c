/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    VDAC8_1_Start();

    Opamp_1_Start();
    UART_Start();

    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    int val = 0;
    char send[100];
   

    for(;;)
    {
        val = ADC_SAR_1_GetResult16();
        
        sprintf(send, "%d\r\n", val);
        UART_PutString(send);
        
        CyDelay(100);
        
    }
}

/* [] END OF FILE */
