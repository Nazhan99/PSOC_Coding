#include "Filter_1.h"
#include "Filter_1_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelABiquadCoefficients Filter_1_ChannelABiquadCoefficients

/* Number of Biquad sections are: 16 */

const uint8 CYCODE Filter_1_ChannelABiquadCoefficients[Filter_1_BIQUAD_A_SIZE] = 
{
 /* Coefficients of Section 0 */
 0x8Bu, 0xD5u, 0x0Cu, 0x00u, /* Section(0)_A0, 0.200533628463745 */

 0xEAu, 0x54u, 0xE6u, 0x00u, /* Section(0)_A1, -0.40106725692749 */

 0x8Bu, 0xD5u, 0x0Cu, 0x00u, /* Section(0)_A2, 0.200533628463745 */

 0x4Du, 0x20u, 0x64u, 0x00u, /* Section(0)_B1, -1.56447148323059 */

 0xBBu, 0xBAu, 0xD6u, 0x00u, /* Section(0)_B2, 0.644852876663208 */

 /* Coefficients of Section 1 */
 0x37u, 0x49u, 0x32u, 0x00u, /* Section(1)_A0, 0.785718679428101 */

 0x93u, 0x6Du, 0x9Bu, 0x00u, /* Section(1)_A1, -1.57143712043762 */

 0x37u, 0x49u, 0x32u, 0x00u, /* Section(1)_A2, 0.785718679428101 */

 0x35u, 0x3Fu, 0x62u, 0x00u, /* Section(1)_B1, -1.53510785102844 */

 0xFAu, 0x26u, 0xD9u, 0x00u, /* Section(1)_B2, 0.606996059417725 */

 /* Coefficients of Section 2 */
 0x6Cu, 0xA1u, 0x31u, 0x00u, /* Section(2)_A0, 0.775477409362793 */

 0x28u, 0xBDu, 0x9Cu, 0x00u, /* Section(2)_A1, -1.55095481872559 */

 0x6Cu, 0xA1u, 0x31u, 0x00u, /* Section(2)_A2, 0.775477409362793 */

 0xB2u, 0x30u, 0x61u, 0x00u, /* Section(2)_B1, -1.51859712600708 */

 0x03u, 0xABu, 0xDAu, 0x00u, /* Section(2)_B2, 0.583312273025513 */

 /* Coefficients of Section 3 */
 0x7Au, 0x5Au, 0x31u, 0x00u, /* Section(3)_A0, 0.77114725112915 */

 0x0Cu, 0x4Bu, 0x9Du, 0x00u, /* Section(3)_A1, -1.5422945022583 */

 0x7Au, 0x5Au, 0x31u, 0x00u, /* Section(3)_A2, 0.77114725112915 */

 0x22u, 0xC7u, 0x60u, 0x00u, /* Section(3)_B1, -1.51215410232544 */

 0x3Bu, 0x5Du, 0xDBu, 0x00u, /* Section(3)_B2, 0.572434663772583 */

 /* Coefficients of Section 4 */
 0x95u, 0xE4u, 0x34u, 0x00u, /* Section(4)_A0, 0.826451539993286 */

 0xD6u, 0x36u, 0x96u, 0x00u, /* Section(4)_A1, -1.65290307998657 */

 0x95u, 0xE4u, 0x34u, 0x00u, /* Section(4)_A2, 0.826451539993286 */

 0x0Du, 0xEDu, 0x66u, 0x00u, /* Section(4)_B1, -1.60821843147278 */

 0xB8u, 0x5Au, 0xD3u, 0x00u, /* Section(4)_B2, 0.697587966918945 */

 /* Coefficients of Section 5 */
 0xB3u, 0xEBu, 0x36u, 0x00u, /* Section(5)_A0, 0.858135938644409 */

 0x99u, 0x28u, 0x92u, 0x00u, /* Section(5)_A1, -1.7162721157074 */

 0xB3u, 0xEBu, 0x36u, 0x00u, /* Section(5)_A2, 0.858135938644409 */

 0x91u, 0xB1u, 0x6Au, 0x00u, /* Section(5)_B1, -1.66708779335022 */

 0xC3u, 0x02u, 0xCFu, 0x00u, /* Section(5)_B2, 0.765456438064575 */

 /* Coefficients of Section 6 */
 0xAAu, 0x7Du, 0x3Fu, 0x00u, /* Section(6)_A0, 0.992044925689697 */

 0xABu, 0x04u, 0x81u, 0x00u, /* Section(6)_A1, -1.98409008979797 */

 0xAAu, 0x7Du, 0x3Fu, 0x00u, /* Section(6)_A2, 0.992044925689697 */

 0x1Eu, 0xF3u, 0x7Eu, 0x00u, /* Section(6)_B1, -1.98358869552612 */

 0x74u, 0xFCu, 0xC0u, 0x00u, /* Section(6)_B2, 0.984591484069824 */

 /* Coefficients of Section 7 */
 0x68u, 0xA1u, 0x02u, 0x00u, /* Section(7)_A0, 0.0411014556884766 */

 0xD0u, 0x42u, 0x05u, 0x00u, /* Section(7)_A1, 0.0822029113769531 */

 0x68u, 0xA1u, 0x02u, 0x00u, /* Section(7)_A2, 0.0411014556884766 */

 0x22u, 0x74u, 0x6Fu, 0x00u, /* Section(7)_B1, -1.74146318435669 */

 0x3Au, 0xB3u, 0xC9u, 0x00u, /* Section(7)_B2, 0.848435878753662 */

 /* Coefficients of Section 8 */
 0x80u, 0x70u, 0x3Fu, 0x00u, /* Section(8)_A0, 0.991241455078125 */

 0x01u, 0x1Fu, 0x81u, 0x00u, /* Section(8)_A1, -1.98248267173767 */

 0x80u, 0x70u, 0x3Fu, 0x00u, /* Section(8)_A2, 0.991241455078125 */

 0xADu, 0x9Bu, 0x7Fu, 0x00u, /* Section(8)_B1, -1.99387669563293 */

 0x2Fu, 0x54u, 0xC0u, 0x00u, /* Section(8)_B2, 0.994861841201782 */

 /* Coefficients of Section 9 */
 0xB9u, 0x5Fu, 0x00u, 0x00u, /* Section(9)_A0, 0.00584244728088379 */

 0x72u, 0xBFu, 0x00u, 0x00u, /* Section(9)_A1, 0.0116848945617676 */

 0xB9u, 0x5Fu, 0x00u, 0x00u, /* Section(9)_A2, 0.00584244728088379 */

 0xC4u, 0x33u, 0x75u, 0x00u, /* Section(9)_B1, -1.83128452301025 */

 0xB0u, 0x73u, 0xC3u, 0x00u, /* Section(9)_B2, 0.946063995361328 */

 /* Coefficients of Section 10 */
 0x3Bu, 0xEFu, 0x01u, 0x00u, /* Section(10)_A0, 0.030226469039917 */

 0x76u, 0xDEu, 0x03u, 0x00u, /* Section(10)_A1, 0.060452938079834 */

 0x3Bu, 0xEFu, 0x01u, 0x00u, /* Section(10)_A2, 0.030226469039917 */

 0x7Au, 0x99u, 0x7Du, 0x00u, /* Section(10)_B1, -1.9624924659729 */

 0x94u, 0x54u, 0xC2u, 0x00u, /* Section(10)_B2, 0.963587760925293 */

 /* Coefficients of Section 11 */
 0x79u, 0xE3u, 0x01u, 0x00u, /* Section(11)_A0, 0.0295088291168213 */

 0xF2u, 0xC6u, 0x03u, 0x00u, /* Section(11)_A1, 0.0590176582336426 */

 0x79u, 0xE3u, 0x01u, 0x00u, /* Section(11)_A2, 0.0295088291168213 */

 0x3Eu, 0xE6u, 0x7Cu, 0x00u, /* Section(11)_B1, -1.9515528678894 */

 0x7Du, 0x06u, 0xC3u, 0x00u, /* Section(11)_B2, 0.952728986740112 */

 /* Coefficients of Section 12 */
 0x5Cu, 0xDBu, 0x01u, 0x00u, /* Section(12)_A0, 0.0290136337280273 */

 0xB8u, 0xB6u, 0x03u, 0x00u, /* Section(12)_A1, 0.0580272674560547 */

 0x5Cu, 0xDBu, 0x01u, 0x00u, /* Section(12)_A2, 0.0290136337280273 */

 0x3Fu, 0x48u, 0x7Eu, 0x00u, /* Section(12)_B1, -1.97315955162048 */

 0xC9u, 0xA6u, 0xC1u, 0x00u, /* Section(12)_B2, 0.974195241928101 */

 /* Coefficients of Section 13 */
 0x05u, 0xCCu, 0x01u, 0x00u, /* Section(13)_A0, 0.0280773639678955 */

 0x0Au, 0x98u, 0x03u, 0x00u, /* Section(13)_A1, 0.056154727935791 */

 0x05u, 0xCCu, 0x01u, 0x00u, /* Section(13)_A2, 0.0280773639678955 */

 0xADu, 0x31u, 0x7Cu, 0x00u, /* Section(13)_B1, -1.94053196907043 */

 0x6Bu, 0xB9u, 0xC3u, 0x00u, /* Section(13)_B2, 0.941807985305786 */

 /* Coefficients of Section 14 */
 0x78u, 0xBCu, 0x01u, 0x00u, /* Section(14)_A0, 0.0271282196044922 */

 0xEFu, 0x78u, 0x03u, 0x00u, /* Section(14)_A1, 0.0542562007904053 */

 0x78u, 0xBCu, 0x01u, 0x00u, /* Section(14)_A2, 0.0271282196044922 */

 0x6Bu, 0x8Cu, 0x7Bu, 0x00u, /* Section(14)_B1, -1.93044543266296 */

 0xB8u, 0x5Cu, 0xC4u, 0x00u, /* Section(14)_B2, 0.931840896606445 */

 /* Coefficients of Section 15 */
 0x76u, 0x6Bu, 0x06u, 0x00u, /* Section(15)_A0, 0.100308895111084 */

 0xEDu, 0xD6u, 0x0Cu, 0x00u, /* Section(15)_A1, 0.200618028640747 */

 0x76u, 0x6Bu, 0x06u, 0x00u, /* Section(15)_A2, 0.100308895111084 */

 0xC8u, 0x1Du, 0x7Bu, 0x00u, /* Section(15)_B1, -1.92369270324707 */

 0xEBu, 0xC9u, 0xC4u, 0x00u, /* Section(15)_B2, 0.925175905227661 */
};

