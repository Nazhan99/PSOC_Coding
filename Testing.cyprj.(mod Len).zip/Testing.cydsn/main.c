/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>


/*******************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    VDAC8_1_Start();
    USBUART_1_Start(0, USBUART_1_5V_OPERATION);
    while (USBUART_1_GetConfiguration()== 0){}
    
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    

    for(;;)
    {
		ADC_SAR_1_IsEndConversion(ADC_SAR_1_WAIT_FOR_RESULT);
        int val =  ADC_SAR_1_CountsTo_mVolts(ADC_SAR_1_GetResult16());
		
/* Change the VDAC to get a changing ADC result */
static uint8 vdac_val = 0;
		VDAC8_1_SetValue(vdac_val++);
		
        char send[100];
        sprintf(send, "%d mV\r\n", val);
        USBUART_1_PutString(send);
        
        CyDelay(100);
        
    }
}

/* [] END OF FILE */
