/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdio.h"		// You left this out.


uint16 chan[2];

/*************************************************************************/
//  I changed this to an interrupt at the end of conversion. This 'guarantees' that the conversion is complete and 
//  Next you pull the data from the ADC before switching the next Amux channel to scan.

    
    

/*************************************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    //VDAC8_1_Start();
    //VDAC8_2_Start();
    //VDAC8_3_Start();
    //VDAC8_4_Start();
    PGA_1_Start();
    PGA_2_Start();
    PGA_Inv_1_Start();
    Opamp_1_Start();
    PWM_1_Start();
    UART_Start();
	ADC_DelSig_1_Start();	// You left this out.
     
    
    int32 val = 0;
    char send[100];
    
    
    for(;;)
    {   
        //sprintf(send, "Chan[0] %d mV\tChan[1] %d mV",  chan[0], chan[1]);
        //UART_PutString(send);
         
        //val = chan[0] - chan[1];
        //val = val*-4;
        val = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        //sprintf(send, "\tChan[0] - Chan[1] = %ld mV\r\n",  val);
        sprintf(send, "%ld\r\n",val);
        UART_PutString(send);
        CyDelay(100);
    }
}

/* [] END OF FILE */
