#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Mode1__DISABLED 1u /* Mode1 */
#define Mode2__DISABLED 1u /* Mode2 */
#define Mode3__DISABLED 1u /* Mode3 */
#define Page_1__DISABLED 1u /* Page 1 */

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
