#include "Filter.h"
#include "Filter_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is FIR
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelAFirCoefficients Filter_ChannelAFirCoefficients

/* Number of FIR filter taps are: 16 */

const uint8 CYCODE Filter_ChannelAFirCoefficients[Filter_FIR_A_SIZE] = 
{
 0x8Bu, 0xF4u, 0xFFu, 0x00u, /* Tap(0), -0.000349640846252441 */

 0x10u, 0x19u, 0x00u, 0x00u, /* Tap(1), 0.000764846801757813 */

 0xB9u, 0x55u, 0x00u, 0x00u, /* Tap(2), 0.00261604785919189 */

 0xDDu, 0xDDu, 0xFDu, 0x00u, /* Tap(3), -0.0166667699813843 */

 0x73u, 0xD4u, 0x04u, 0x00u, /* Tap(4), 0.0377334356307983 */

 0x1Au, 0xD1u, 0xFBu, 0x00u, /* Tap(5), -0.0326812267303467 */

 0x9Cu, 0xFAu, 0xF6u, 0x00u, /* Tap(6), -0.0704770088195801 */

 0xCBu, 0x1Du, 0x4Au, 0x00u, /* Tap(7), 0.579034209251404 */

 0xCBu, 0x1Du, 0x4Au, 0x00u, /* Tap(8), 0.579034209251404 */

 0x9Cu, 0xFAu, 0xF6u, 0x00u, /* Tap(9), -0.0704770088195801 */

 0x1Au, 0xD1u, 0xFBu, 0x00u, /* Tap(10), -0.0326812267303467 */

 0x73u, 0xD4u, 0x04u, 0x00u, /* Tap(11), 0.0377334356307983 */

 0xDDu, 0xDDu, 0xFDu, 0x00u, /* Tap(12), -0.0166667699813843 */

 0xB9u, 0x55u, 0x00u, 0x00u, /* Tap(13), 0.00261604785919189 */

 0x10u, 0x19u, 0x00u, 0x00u, /* Tap(14), 0.000764846801757813 */

 0x8Bu, 0xF4u, 0xFFu, 0x00u, /* Tap(15), -0.000349640846252441 */
};

