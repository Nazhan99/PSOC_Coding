/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>


#define PGA_1_GAIN	8u


/*********************************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    PGA_1_Start();
    PGA_2_Start();
    UART_Start();


    ADC_DelSig_1_IRQ_Start();
    ADC_DelSig_1_Start();
    ADC_DelSig_1_StartConvert();
    int val = 0;
    char send[100];

    for(;;)
    {   
       
        val = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        sprintf(send, "%d \r\n",  val);
        UART_PutString(send);
        CyDelay(100);
        
    }
}


/* [] END OF FILE */
