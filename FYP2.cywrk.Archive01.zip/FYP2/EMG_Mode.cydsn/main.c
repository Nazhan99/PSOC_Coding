/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>


uint8 amux_chan = 0; //InputMux channel
uint8 amux1_chan = 0; //InputMux_1 channel
uint8 mode = 1;

uint8 pga_gain_tbl[] = {1,2,4,8,16,24,32,48,50};
uint8 pga_inv_gain_tbl[] = {1,3,7,15,22,24,31,47,49};

uint8 pga_1_gain = 1;
uint8 pga_1_inv_gain = 1;
uint8 pga_2_gain = 1;
uint8 pga_3_gain = 1;
uint16 pga_gain_tot = 1;

uint8 mode_1_InputMux[] = {0, 3, 4};
#define mode_1_InputMux_NUM_CHANS  (sizeof(mode_1_InputMux)/sizeof(mode_1_InputMux[0]))
/*********************************************************************/
CY_ISR(sw_isr) //change Input_Mux channels
{
	amux_chan++;
	if(amux_chan >= mode_1_InputMux_NUM_CHANS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	InputMux_FastSelect(mode_1_InputMux[amux_chan]);
}

uint8 mode_2_InputMux[] = {1, 2};
#define mode_2_InputMux_NUM_CHANS  (sizeof(mode_2_InputMux)/sizeof(mode_2_InputMux[0]))
/*********************************************************************/
CY_ISR(sw2_isr) //change modes
{
	amux_chan++;
	if(amux_chan >= mode_2_InputMux_NUM_CHANS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	InputMux_FastSelect(mode_2_InputMux[amux_chan]);

}

uint8 mode_3_InputMux_1[] = {0, 1};
#define mode_3_InputMux_1_NUM_CHANS  (sizeof(mode_3_InputMux_1)/sizeof(mode_3_InputMux_1[0]))
/*********************************************************************/
CY_ISR(sw3_isr) //change modes
{
	amux_chan++;
	if(amux_chan >= mode_3_InputMux_1_NUM_CHANS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	InputMux_1_FastSelect(mode_3_InputMux_1[amux_chan]);
}

/*********************************************************************/
void set_mode(uint8 new_mode)
{
	// Disable previously set isr routines.
	isr_sw_Stop();

	if (new_mode==1){ //mode 1 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Stop();
        PGA_Inv_1_Stop();
        PGA_2_Start();
		pga_2_gain = pga_gain_tbl[PGA_2_GAIN_08];
	    PGA_2_SetGain(PGA_2_GAIN_08);
		PGA_3_Stop();
		pga_gain_tot = pga_2_gain;
	// Input mux settings
        InputMux_1_DisconnectAll();
        InputMux_2_DisconnectAll();
        InputMux_3_FastSelect(0);
        InputMux_Start();
        InputMux_FastSelect(mode_1_InputMux[amux_chan]);

	// Start channel switch ISR
 		isr_sw_StartEx(&sw_isr);
		isr_sw_ClearPending();     
    }
    
    if (new_mode==2){ //mode 2 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Start();
		pga_1_gain = pga_gain_tbl[PGA_1_GAIN_08];
        PGA_1_SetGain(PGA_1_GAIN_08);
        PGA_Inv_1_Start();
		pga_1_inv_gain = pga_inv_gain_tbl[PGA_Inv_1_GAIN_07];
        PGA_Inv_1_SetGain(PGA_Inv_1_GAIN_07);
        PGA_2_Start();
		pga_2_gain = pga_gain_tbl[PGA_2_GAIN_01];
        PGA_2_SetGain(PGA_2_GAIN_01);
		pga_gain_tot = pga_2_gain;
        PGA_3_Stop();
		pga_gain_tot = pga_2_gain * pga_1_gain;
	// Input mux settings
        InputMux_1_Start();
        InputMux_1_FastSelect(0);
        InputMux_2_Start();
        InputMux_2_FastSelect(0);
        InputMux_3_Start();
        InputMux_3_FastSelect(0);
        InputMux_Start();
        InputMux_FastSelect(amux_chan);
        
	// Start channel switch ISR
 		isr_sw_StartEx(&sw2_isr);
		isr_sw_ClearPending();
    }
    
    if (new_mode==3){ //mode 3 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Start();
		pga_1_gain = pga_gain_tbl[PGA_1_GAIN_01];
        PGA_1_SetGain(PGA_1_GAIN_01);
        PGA_Inv_1_Start();
		pga_1_inv_gain = pga_inv_gain_tbl[PGA_Inv_1_GAIN_01];
        PGA_Inv_1_SetGain(PGA_Inv_1_GAIN_01);
        PGA_2_Stop();
        PGA_3_Start();
		pga_3_gain = pga_gain_tbl[PGA_3_GAIN_01];
        PGA_3_SetGain(PGA_3_GAIN_01);
		pga_gain_tot = pga_3_gain * pga_1_gain;
	// Input mux settings
		InputMux_2_Start();
        InputMux_2_FastSelect(1);
        InputMux_3_Start();
        InputMux_3_FastSelect(1);
        InputMux_DisconnectAll();
        InputMux_1_Start();
        InputMux_1_FastSelect(amux_chan); 

	// Start channel switch ISR
		isr_sw_StartEx(&sw3_isr);
		isr_sw_ClearPending();
    }
}

/*********************************************************************/
int main(void)
{
	CyGlobalIntEnable; /* Enable global interrupts. */
    
    set_mode(mode);
	
    UART_Start();
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    int val = 0;
    char send[100];

    for(;;)
    {
	char c;
		if((c = UART_GetChar()) != '\0')
		{	// Switch modes on-the-fly
		uint8 mode_prev = mode;
			switch(c)
			{
			case '1':  mode = 1; break;
			case '2':  mode = 2; break;
			case '3':  mode = 3; break;
			default: break;	// do nothing
			}
			if(mode_prev != mode)
			{
			    set_mode(mode);
			}
		}
        val = ADC_SAR_1_CountsTo_mVolts(  ADC_SAR_1_GetResult16());
        sprintf(send, "Mode %d   Chan %1d: %d mV\r\n", mode,  amux_chan,  val/pga_gain_tot);
        UART_PutString(send);
        CyDelay(100);
    }
}

/* [] END OF FILE */
