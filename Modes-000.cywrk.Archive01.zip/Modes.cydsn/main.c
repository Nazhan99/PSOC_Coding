/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <cydisabledsheets.h>




uint8 amux_chan = 0;
/*********************************************************************/
CY_ISR(sw_isr)
{
	amux_chan++;
	if(amux_chan >= InputMux_CHANNELS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	InputMux_FastSelect(amux_chan);
}

#define PGA_1_GAIN	8u
/*********************************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    #if (Mode_2__DISABLED) && (Mode_3__DISABLED) //mode 1 enables
    VDAC8_1_Start();
    VDAC8_2_Start();
    VDAC8_3_Start();
    PGA_1_Start();
    #endif
    
    
    #if !(Mode_2__DISABLED) //mode 2 enables
    VDAC8_1_Start();
    VDAC8_2_Start();
    PGA_1_Start();
    PGA_Inv_1_Start();
    #endif
    
    #if !(Mode_3__DISABLED) //mode 3 enables
    VDAC8_1_Start();
    VDAC8_2_Start();
    VDAC8_3_Start();
    PGA_1_Start();
    PGA_2_Start();
    PGA_Inv_1_Start();
    #endif
    
    InputMux_Start();
    InputMux_FastSelect(amux_chan);
    UART_Start();
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    int val = 0;
    char send[100];

	isr_sw_StartEx(&sw_isr);
	isr_sw_ClearPending();

    for(;;)
    {
        
        val = ADC_SAR_1_CountsTo_mVolts(  ADC_SAR_1_GetResult16());
        sprintf(send, "Chan %1d: %d mV\r\n", amux_chan,  val/PGA_1_GAIN);
        UART_PutString(send);
        CyDelay(100);
        
    }
}

/* [] END OF FILE */
