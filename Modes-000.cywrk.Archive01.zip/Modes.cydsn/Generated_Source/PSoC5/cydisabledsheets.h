#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Mode_1__DISABLED 1u /* Mode_1 */
#define Mode_3__DISABLED 1u /* Mode_3 */

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
