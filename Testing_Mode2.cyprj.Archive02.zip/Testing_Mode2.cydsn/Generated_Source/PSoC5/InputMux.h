/*******************************************************************************
* File Name: InputMux.h
* Version 1.80
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_InputMux_H)
#define CY_AMUX_InputMux_H

#include "cyfitter.h"
#include "cyfitter_cfg.h"

#if ((CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) || \
         (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC4) || \
         (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC5))    
    #include "cytypes.h"
#else
    #include "syslib/cy_syslib.h"
#endif /* ((CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) */


/***************************************
*        Function Prototypes
***************************************/

void InputMux_Start(void) ;
#define InputMux_Init() InputMux_Start()
void InputMux_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void InputMux_Stop(void); */
/* void InputMux_Select(uint8 channel); */
/* void InputMux_Connect(uint8 channel); */
/* void InputMux_Disconnect(uint8 channel); */
/* void InputMux_DisconnectAll(void) */


/***************************************
*         Parameter Constants
***************************************/

#define InputMux_CHANNELS  2u
#define InputMux_MUXTYPE   1
#define InputMux_ATMOSTONE 1

/***************************************
*             API Constants
***************************************/

#define InputMux_NULL_CHANNEL 0xFFu
#define InputMux_MUX_SINGLE   1
#define InputMux_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if InputMux_MUXTYPE == InputMux_MUX_SINGLE
# if !InputMux_ATMOSTONE
#  define InputMux_Connect(channel) InputMux_Set(channel)
# endif
# define InputMux_Disconnect(channel) InputMux_Unset(channel)
#else
# if !InputMux_ATMOSTONE
void InputMux_Connect(uint8 channel) ;
# endif
void InputMux_Disconnect(uint8 channel) ;
#endif

#if InputMux_ATMOSTONE
# define InputMux_Stop() InputMux_DisconnectAll()
# define InputMux_Select(channel) InputMux_FastSelect(channel)
void InputMux_DisconnectAll(void) ;
#else
# define InputMux_Stop() InputMux_Start()
void InputMux_Select(uint8 channel) ;
# define InputMux_DisconnectAll() InputMux_Start()
#endif

#endif /* CY_AMUX_InputMux_H */


/* [] END OF FILE */
