/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdio.h"		// You left this out.

uint8 amux_chan = 0;

int16 chan;

/*************************************************************************/
//  I changed this to an interrupt at the end of conversion. This 'guarantees' that the conversion is complete and 
//  Next you pull the data from the ADC before switching the next Amux channel to scan.
CY_ISR(eoc_isr)
{
	chan = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());	// Read the converted ADC value and store
//	amux_chan++;
//	if(amux_chan >= AMux_1_CHANNELS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
//	AMux_1_FastSelect(amux_chan);
}
    
    

/*************************************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    //VDAC8_1_Start();
    //VDAC8_2_Start();
    //VDAC8_3_Start();
//    VDAC8_4_Start();
    PGA_1_Start();
    
//    Opamp_1_Start();
    PWM_1_Start();
    UART_Start();
	ADC_DelSig_1_Start();	// You left this out.
    
//    AMux_1_FastSelect(amux_chan); // default chan 0 
    
//    int32 val = 0;
    char send[100];
    
    isr_eoc_StartEx(eoc_isr);
	isr_eoc_ClearPending();
    
    for(;;)
    {   
//        sprintf(send, "Chan[0] %d mV\tChan[1] %d mV",  chan[0], chan[1]);
//        UART_PutString(send);
         
//        val = chan[0] - chan[1];
        //val = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        //sprintf(send, "PGA_1 - PGA_2 = %hd mV\r\n",  chan);
        sprintf(send, "%hd\r\n",  chan);
        UART_PutString(send);
        CyDelay(100);
    }
}

/* [] END OF FILE */
