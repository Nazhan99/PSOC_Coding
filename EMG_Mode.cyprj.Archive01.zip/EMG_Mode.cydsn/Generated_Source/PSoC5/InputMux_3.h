/*******************************************************************************
* File Name: InputMux_3.h
* Version 1.80
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_InputMux_3_H)
#define CY_AMUX_InputMux_3_H

#include "cyfitter.h"
#include "cyfitter_cfg.h"

#if ((CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) || \
         (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC4) || \
         (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC5))    
    #include "cytypes.h"
#else
    #include "syslib/cy_syslib.h"
#endif /* ((CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) */


/***************************************
*        Function Prototypes
***************************************/

void InputMux_3_Start(void) ;
#define InputMux_3_Init() InputMux_3_Start()
void InputMux_3_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void InputMux_3_Stop(void); */
/* void InputMux_3_Select(uint8 channel); */
/* void InputMux_3_Connect(uint8 channel); */
/* void InputMux_3_Disconnect(uint8 channel); */
/* void InputMux_3_DisconnectAll(void) */


/***************************************
*         Parameter Constants
***************************************/

#define InputMux_3_CHANNELS  2u
#define InputMux_3_MUXTYPE   1
#define InputMux_3_ATMOSTONE 1

/***************************************
*             API Constants
***************************************/

#define InputMux_3_NULL_CHANNEL 0xFFu
#define InputMux_3_MUX_SINGLE   1
#define InputMux_3_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if InputMux_3_MUXTYPE == InputMux_3_MUX_SINGLE
# if !InputMux_3_ATMOSTONE
#  define InputMux_3_Connect(channel) InputMux_3_Set(channel)
# endif
# define InputMux_3_Disconnect(channel) InputMux_3_Unset(channel)
#else
# if !InputMux_3_ATMOSTONE
void InputMux_3_Connect(uint8 channel) ;
# endif
void InputMux_3_Disconnect(uint8 channel) ;
#endif

#if InputMux_3_ATMOSTONE
# define InputMux_3_Stop() InputMux_3_DisconnectAll()
# define InputMux_3_Select(channel) InputMux_3_FastSelect(channel)
void InputMux_3_DisconnectAll(void) ;
#else
# define InputMux_3_Stop() InputMux_3_Start()
void InputMux_3_Select(uint8 channel) ;
# define InputMux_3_DisconnectAll() InputMux_3_Start()
#endif

#endif /* CY_AMUX_InputMux_3_H */


/* [] END OF FILE */
