/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"


uint8 amux_chan = 0;

CY_ISR(isr_1)
{
	amux_chan++;
	if(amux_chan >= AMux_1_CHANNELS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	AMux_1_FastSelect(amux_chan);
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    VDAC8_1_Start();
    VDAC8_2_Start();
    VDAC8_3_Start();
    VDAC8_4_Start();
    PGA_1_Start();
    PGA_2_Start();
    Opamp_1_Start();
    UART_Start();
    
    AMux_1_FastSelect(amux_chan); // default chan 0 
    ADC_DelSig_1_Start();
    ADC_DelSig_1_StartConvert();
    int val = 0; // value of subtract diff_1 - diff_2
    int diff_1=0; //reading at chan 0
    int diff_2=0; //reading at chan 1
    char send[100];
    
    isr_1_StartEx(&isr_1);
	isr_1_ClearPending();
    
    
    for(;;)
    {   
        if(amux_chan==0){
        diff_1=ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        }
        else if(amux_chan==1){
        diff_2=ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        }
        
        val = diff_1-diff_2;
        sprintf(send, "%d \r\n",  val);
        UART_PutString(send);
        CyDelay(100);
    }
}

/* [] END OF FILE */
