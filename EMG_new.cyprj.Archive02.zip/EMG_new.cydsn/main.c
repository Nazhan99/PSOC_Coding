/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>


uint8 amux_chan = 0; //InputMux channel
uint8 amux2_chan = 0;
uint8 mode = 1;
uint16 chan[2];


uint8 pga_1_gain = 1;
uint8 pga_2_gain = 1;
uint8 pga_3_gain = 1;

uint8 mode_1_InputMux[] = {0,1,2};
#define mode_1_InputMux_NUM_CHANS  (sizeof(mode_1_InputMux)/sizeof(mode_1_InputMux[0]))
/*********************************************************************/
CY_ISR(sw_isr) //change Input_Mux channels
{
	amux_chan++;
	if(amux_chan >= mode_1_InputMux_NUM_CHANS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	InputMux_FastSelect(mode_1_InputMux[amux_chan]);
}

CY_ISR(eoc_isr)
{
	chan[amux2_chan] = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());	// Read the converted ADC value and store
	amux_chan++;
	if(amux2_chan >= AMux_2_CHANNELS) amux2_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	AMux_2_FastSelect(amux2_chan);
}


/*********************************************************************/
void set_mode(uint8 new_mode)
{
	// Disable previously set isr routines.
	isr_sw_Stop();
    isr_eoc_Stop();

	if (new_mode==1){ //mode 1 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Start();
        PGA_1_SetGain(1);
        PGA_2_Stop();
        PGA_3_Stop();
        PGA_4_Start();
        PGA_4_SetGain(1);
        Opamp_1_Start();

        
	// Input mux settings
        InputMux_Start();
        InputMux_FastSelect(mode_1_InputMux[amux_chan]);
        AMux_1_Start();
        AMux_1_FastSelect(1);
        AMux_2_Start();
        AMux_2_FastSelect(0);
        AMux_3_Start();
        AMux_3_FastSelect(0);
        

	// Start channel switch ISR
 		isr_sw_StartEx(&sw_isr);
		isr_sw_ClearPending();     
    }
    
    if (new_mode==2){ //mode 2 enables
        amux2_chan = 0;
	

	// PGA settings
        PGA_1_Start();
        PGA_1_SetGain(1);
        PGA_2_Start();
        PGA_2_SetGain(1);
        PGA_3_Stop();
        PGA_4_Start();
        PGA_4_SetGain(1);
		Opamp_1_Start();
        
	// Input mux settings
        InputMux_Start();
        InputMux_FastSelect(0);
        AMux_1_Start();
        AMux_1_FastSelect(0);
        AMux_2_Start();
        AMux_3_Start();
        AMux_3_FastSelect(0);
        
    // different chan 0 and chan 1
        isr_eoc_StartEx(eoc_isr);
	    isr_eoc_ClearPending();
        
    }
    
    if (new_mode==3){ //mode 3 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Start();
        PGA_1_SetGain(1);
        PGA_2_Start();
        PGA_2_SetGain(1);
        PGA_3_Start();
		PGA_3_SetGain(1);
        PGA_4_Start();
        PGA_4_SetGain(1);
        Opamp_1_Start();
        
	// Input mux settings
		InputMux_Start();
        InputMux_FastSelect(0);
        AMux_1_Start();
        AMux_1_FastSelect(0);
        AMux_2_Start();
        AMux_2_DisconnectAll();
        AMux_3_Start();
        AMux_3_FastSelect(1);

    }
}

/*********************************************************************/
int main(void)
{
	CyGlobalIntEnable; /* Enable global interrupts. */
    
    set_mode(mode);
	
    UART_Start();
    PWM_1_Start();
    ADC_DelSig_1_Start();
    ADC_DelSig_1_StartConvert();
    int val = 0;
    char send[100];

    for(;;)
    {
	char c;
		if((c = UART_GetChar()) != '\0')
		{	// Switch modes on-the-fly
		uint8 mode_prev = mode;
			switch(c)
			{
			case '1':  mode = 1; break;
			case '2':  mode = 2; break;
			case '3':  mode = 3; break;
			default: break;	// do nothing
			}
			if(mode_prev != mode)
			{
			    set_mode(mode);
			}
		}
        if (mode == 2){
            
            val = chan[0] - chan[1];
        //val = val*-4;
        //val = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        //sprintf(send, "\tChan[0] - Chan[1] = %ld mV\r\n",  val);
            sprintf(send, "%1d\r\n",val);
            UART_PutString(send);
            CyDelay(100);
        
        }
        
        val = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());
        sprintf(send, "Mode %d   Chan %1d: %d mV\r\n", mode,  amux_chan,  val);
        UART_PutString(send);
        CyDelay(100);
    }
}

/* [] END OF FILE */
