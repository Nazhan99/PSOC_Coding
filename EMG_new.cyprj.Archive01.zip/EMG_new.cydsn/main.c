/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>


uint8 amux_chan = 0; //InputMux channel
uint8 mode = 1;

uint8 pga_gain_tbl[] = {1,2,4,8,16,24,32,48,50};

uint8 pga_1_gain = 1;
uint8 pga_2_gain = 1;
uint8 pga_3_gain = 1;

uint8 mode_1_InputMux[] = {0,1,2};
#define mode_1_InputMux_NUM_CHANS  (sizeof(mode_1_InputMux)/sizeof(mode_1_InputMux[0]))
/*********************************************************************/
CY_ISR(sw_isr) //change Input_Mux channels
{
	amux_chan++;
	if(amux_chan >= mode_1_InputMux_NUM_CHANS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	InputMux_FastSelect(mode_1_InputMux[amux_chan]);
}

CY_ISR(eoc_isr)
{
	chan[amux_chan] = ADC_DelSig_1_CountsTo_mVolts(  ADC_DelSig_1_GetResult16());	// Read the converted ADC value and store
	amux_chan++;
	if(amux_chan >= AMux_1_CHANNELS) amux_chan = 0;	// don't exceed the number of Amux channels else wrap-around
	AMux_1_FastSelect(amux_chan);
}


/*********************************************************************/
void set_mode(uint8 new_mode)
{
	// Disable previously set isr routines.
	isr_sw_Stop();

	if (new_mode==1){ //mode 1 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Start();
        PGA_1_SetGain(1);
        PGA_2_Stop();
        PGA_3_Stop();
        Opamp_1_Start();
		pga_1_gain = pga_gain_tbl[1];
		pga_gain_tot = pga_1_gain;
        
	// Input mux settings
        InputMux_Start();
        InputMux_FastSelect(mode_1_InputMux[amux_chan]);
        Amux_1_Start();
        Amux_1_FastSelect(1);
        Amux_2_Start();
        Amux_2_FastSelect(0);
        Amux_3_Start();
        Amux_3_FastSelect(0);
        

	// Start channel switch ISR
 		isr_sw_StartEx(&sw_isr);
		isr_sw_ClearPending();     
    }
    
    if (new_mode==2){ //mode 2 enables
	

	// PGA settings
        PGA_1_Start();
        PGA_1_SetGain(1);
        PGA_2_Start();
        PGA_2_SetGain(1);
        PGA_3_Stop();
		Opamp_1_Start();
        
	// Input mux settings
        InputMux_Start();
        InputMux_FastSelect(0);
        Amux_1_Start();
        Amux_1_FastSelect(0);
        Amux_2_Start();
        //Amux_2_FastSelect(0);
        Amux_3_Start();
        Amux_3_FastSelect(0);
        
    // different chan 0 and chan 1
        isr_eoc_StartEx(eoc_isr);
	    isr_eoc_ClearPending();
        
        
    }
    
    if (new_mode==3){ //mode 3 enables
		amux_chan = 0;

	// PGA settings
        PGA_1_Start();
		pga_1_gain = pga_gain_tbl[PGA_1_GAIN_01];
        PGA_1_SetGain(PGA_1_GAIN_01);
        PGA_Inv_1_Start();
		pga_1_inv_gain = pga_inv_gain_tbl[PGA_Inv_1_GAIN_01];
        PGA_Inv_1_SetGain(PGA_Inv_1_GAIN_01);
        PGA_2_Stop();
        PGA_3_Start();
		pga_3_gain = pga_gain_tbl[PGA_3_GAIN_01];
        PGA_3_SetGain(PGA_3_GAIN_01);
		pga_gain_tot = pga_3_gain * pga_1_gain;
	// Input mux settings
		InputMux_2_Start();
        InputMux_2_FastSelect(1);
        InputMux_3_Start();
        InputMux_3_FastSelect(1);
        InputMux_DisconnectAll();
        InputMux_1_Start();
        InputMux_1_FastSelect(amux_chan); 

	// Start channel switch ISR
		isr_sw_StartEx(&sw3_isr);
		isr_sw_ClearPending();
    }
}

/*********************************************************************/
int main(void)
{
	CyGlobalIntEnable; /* Enable global interrupts. */
    
    set_mode(mode);
	
    UART_Start();
    PWM_1_Start();
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    int val = 0;
    char send[100];

    for(;;)
    {
	char c;
		if((c = UART_GetChar()) != '\0')
		{	// Switch modes on-the-fly
		uint8 mode_prev = mode;
			switch(c)
			{
			case '1':  mode = 1; break;
			case '2':  mode = 2; break;
			case '3':  mode = 3; break;
			default: break;	// do nothing
			}
			if(mode_prev != mode)
			{
			    set_mode(mode);
			}
		}
        val = ADC_SAR_1_CountsTo_mVolts(  ADC_SAR_1_GetResult16());
        sprintf(send, "Mode %d   Chan %1d: %d mV\r\n", mode,  amux_chan,  val/pga_gain_tot);
        UART_PutString(send);
        CyDelay(100);
    }
}

/* [] END OF FILE */
